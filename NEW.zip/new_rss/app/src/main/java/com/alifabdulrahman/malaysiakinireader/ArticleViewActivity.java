package com.alifabdulrahman.malaysiakinireader;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class ArticleViewActivity extends AppCompatActivity implements View.OnClickListener, AudioManager.OnAudioFocusChangeListener {

    private ArrayList<ArticleData> articleDatas;
    private TextToSpeech tts;
    private WebView mWebView;
    private String url, newsType;
    private ImageButton pauseBtn, nextArc, prevArc, nextSent, prevSent;
    private int index;
    private int readIndex;
    private AudioManager audioManager;
    private boolean orderLatest;

    Button sharebutton;
    @SuppressLint("WrongViewCast")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_view);

        //Set buttons to view
        pauseBtn = findViewById(R.id.pausebtn);
        nextArc = findViewById(R.id.nxtarcbtn);
        prevArc = findViewById(R.id.prevarcbtn);
        nextSent = findViewById(R.id.forwbtn);
        prevSent = findViewById(R.id.prevbtn);
        sharebutton = findViewById(R.id.sharebutton);

        //set listener to buttons
        pauseBtn.setOnClickListener(this);
        nextArc.setOnClickListener(this);
        prevArc.setOnClickListener(this);
        nextSent.setOnClickListener(this);
        prevSent.setOnClickListener(this);
        sharebutton.setOnClickListener(this);

        //Get clicked article from NewsListing
//        loadSettings();
        orderLatest = getIntent().getExtras().getBoolean("OrderLatest");
        newsType = getIntent().getExtras().getString("NewsType");
        index = getIntent().getExtras().getInt("index");
        loadData();

        //set to read from first sentence
        readIndex = 0;


        //Get the url to display an set up webview
        url = articleDatas.get(index).getLink();

        mWebView = findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);

        initializeTTS();
    }

    //Initialize the Text to Speech
    private void initializeTTS(){
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String utteranceId) {
                            Toast.makeText(ArticleViewActivity.this, "TTS initialization successful", Toast.LENGTH_LONG).show();
                        }

                        //What to do after tts has done speaking the current text
                        @Override
                        public void onDone(String utteranceId) {
                            readIndex++;
                            //if there are still more sentences in article, continue reading
                            if(readIndex < articleDatas.get(index).getContent().size()){
                                speakSentences(articleDatas.get(index).getContent());
                            }
                            //Else, update UI with next article and read it
                            else{
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        moveArticle(true);
                                    }
                                });
                            }
                        }

                        @Override
                        public void onError(String utteranceId) {
                            Log.e("UtteranceError", " " + utteranceId);
                        }
                    });
                    //Set the language of TTS
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This lzanguage is not supported");
                    }

                    readFreeOrPaid();

                }
                else
                    Log.e("error", "TTS initialization failed!");
            }
        });
    }

    //Decide based on article type.
    private void readFreeOrPaid(){
        //if free just use the news contents obtained in ArticleListingActivity
        if(!articleDatas.get(index).getPaidNews()){
            loadFreeWebView();
            speakSentences(articleDatas.get(index).getContent());
        }
        //else, if it's paid content, get HTML from webview to read the full article (if user is logged in)
        else{
            loadWebView();
            speakSentences(articleDatas.get(index).getContent());
        }
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(tts != null){
            tts.stop();
            //tts.shutdown();
        }
        removeAudioFocus();
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    private void loadFreeWebView(){
        mWebView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading (WebView view, String url){
                return false;
            }
        });
        mWebView.loadUrl(url);
    }

    /*
    Open the paid articles and inject javascript to scrap the HTML contents when it has finished
    loading. The problem is that onPageFinished doesn't actually wait for the page to finish.

    I think this is still the culprit as Android onPageFinished have different definition of when the page is actually done loading
    I'm not sure if they ever updated that if there are other alternative to view a webpage from an app.
    The onPageFinished method from the Android WebView consider the page finished loading even MalaysiaKini is still loading other stuff through javascript.
    I think one of the way to check is checking if the content fetched contain the "To continue reading please subscribe..."
    before reading the news
     */
    private void loadWebView(){
        //mWebView.addJavascriptInterface(new GetHTML(this), "Scrap");
        mWebView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading (WebView view, String url){
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url){
                super.onPageFinished(view, url);
                mWebView.loadUrl("javascript:window.Scrap.getHTML" +
                        "(document.getElementsByTagName('html')[0].outerHTML);");
            }


        });

        mWebView.loadUrl(url);
    }

    //Get the HTML loaded from webview and scrap it to get the article contents
    public class GetHTML{
        private Context ctx;

        public GetHTML(Context ctx){
            this.ctx = ctx;
        }

        @JavascriptInterface
        public void getHTML(String html){

            //Basically the same thing as in ArticleListingActivity GetContents
            Document doc = Jsoup.parse(html);

            ArrayList<String> tempList = new ArrayList<>();
            tempList.clear();

            if(articleDatas.get(index).getAuthor().equals("-") || articleDatas.get(index).getAuthor().equals("Bernama") || articleDatas.get(index).getAuthor().equals("Reuters")){
                tempList.add(articleDatas.get(index).getTitle());
            }
            else{
                tempList.add(articleDatas.get(index).getTitle() + ". By " + articleDatas.get(index).getAuthor());
            }

            Elements contentContainer = doc.select("div[class$=content-container]");
            Elements classContents =  contentContainer.select("div[class$=content]");
            Elements contents = classContents.select("p");
            for(Element content : contents){
                if(!(content.text().equals(""))){
                    tempList.add(content.text());
                }
            }

            articleDatas.get(index).getContent().clear();
            articleDatas.get(index).setContent(tempList);


            //prevent duplicate TTS instance on paid news.
            if(!tts.isSpeaking()){
                speakSentences(articleDatas.get(index).getContent());
            }

        }
    }

    //Speak the array of sentences.
    private void speakSentences(ArrayList<String> textToRead){
        if(requestAudioFocus()){
            tts.speak(textToRead.get(readIndex), TextToSpeech.QUEUE_FLUSH, null, TextToSpeech.ACTION_TTS_QUEUE_PROCESSING_COMPLETED);
            pauseBtn.setImageResource(android.R.drawable.ic_media_pause);
        }
    }

    private void pausePlay(){
        if(tts.isSpeaking()){
            tts.stop();
            removeAudioFocus();
            pauseBtn.setImageResource(android.R.drawable.ic_media_play);
        }
        else{
            speakSentences(articleDatas.get(index).getContent());
            pauseBtn.setImageResource(android.R.drawable.ic_media_pause);
        }
    }

    @Override
    public void onClick(View v){
        switch (v.getId()) {
            case R.id.pausebtn:
                pausePlay();
                break;
            case R.id.nxtarcbtn:
                moveArticle(true);
                break;
            case R.id.prevarcbtn:
                moveArticle(false);
                break;
            case R.id.forwbtn:
                nextSentence();
                break;
            case R.id.prevbtn:
                previousSentence();
                break;
            case R.id.sharebutton:
                Intent myIntent = new Intent(Intent.ACTION_SEND);
                myIntent.setType("text/plain");
                String shareBody = "I'm sharing this article with you: " + url;
                myIntent.putExtra(Intent.EXTRA_SUBJECT, shareBody);
                myIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(myIntent, "Share using"));
        }
    }

    //Go to next article based on direction(decided by user/system)
    public void moveArticle(boolean dir){
        if(dir) {
            if((index + 1) > articleDatas.size()-1)
                Toast.makeText(ArticleViewActivity.this, "This is the last article", Toast.LENGTH_SHORT).show();
            else{
                if(tts.isSpeaking())
                    tts.stop();
                readIndex = 0;
                index++;
                url = articleDatas.get(index).getLink();
                articleDatas.get(index).setReadNews(true);
                saveData();
                readFreeOrPaid();
            }
        }
        else{
            if((index) < 1)
                Toast.makeText(ArticleViewActivity.this, "This is the first article", Toast.LENGTH_SHORT).show();
            else {
                if(tts.isSpeaking())
                    tts.stop();
                readIndex = 0;
                index--;
                url = articleDatas.get(index).getLink();
                articleDatas.get(index).setReadNews(true);
                saveData();
                readFreeOrPaid();
            }
        }
    }


    private void nextSentence(){
        if(readIndex < articleDatas.get(index).getContent().size() - 1){
            readIndex++;
            if(tts.isSpeaking())
                tts.stop();
            speakSentences(articleDatas.get(index).getContent());
        }
        else{
            moveArticle(true);
        }
    }

    private void previousSentence(){
        if(readIndex > 0){
            readIndex--;
            if(tts.isSpeaking())
                tts.stop();
            speakSentences(articleDatas.get(index).getContent());
        }
        else{
            moveArticle(false);
        }
    }

    @Override
    public void onAudioFocusChange(int focusState){
        switch (focusState) {
            case AudioManager.AUDIOFOCUS_GAIN:
                // resume playback
                speakSentences(articleDatas.get(index).getContent());
                break;
            case AudioManager.AUDIOFOCUS_LOSS:
                // stop playback
                if(tts.isSpeaking()) {
                    tts.stop();
                    pauseBtn.setImageResource(android.R.drawable.ic_media_play);
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // stop playback
                if(tts.isSpeaking()) {
                tts.stop();
                pauseBtn.setImageResource(android.R.drawable.ic_media_play);
            }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                // stop playback
                if(tts.isSpeaking()) {
                    tts.stop();
                    pauseBtn.setImageResource(android.R.drawable.ic_media_play);
                }
                break;
        }
    }

    private boolean requestAudioFocus() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int result = audioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            //Focus gained
            return true;
        }
        //Could not gain focus
        return false;
    }

    private boolean removeAudioFocus() {
        try{
            if(audioManager != null){
                return AudioManager.AUDIOFOCUS_REQUEST_GRANTED ==
                        audioManager.abandonAudioFocus(this);
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        return true;
    }

    private void saveData(){
        SharedPreferences sp = getSharedPreferences("NewsStorage", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        String json;

        //save in latest order
        ArrayList<ArticleData> toSaveInOrder = new ArrayList<>(articleDatas);
        Collections.sort(toSaveInOrder, new Comparator<ArticleData>() {
            @Override
            public int compare(ArticleData o1, ArticleData o2) {
                return o1.getPublishDate().compareTo(o2.getPublishDate());
            }
        });
        Collections.reverse(toSaveInOrder);

        json = gson.toJson(toSaveInOrder);

        editor.putString(newsType, json);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sp = getSharedPreferences("NewsStorage", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sp.getString(newsType, null);
        Type dataType = new TypeToken<ArrayList<ArticleData>>() {}.getType();
        articleDatas = gson.fromJson(json, dataType);

        if(!orderLatest){
            Collections.reverse(articleDatas);
        }

    }

}
