package com.alifabdulrahman.malaysiakinireader;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;


public class MainActivity extends AppCompatActivity implements Serializable {

    private int backButtonCount = 0;
    private ArrayList<NewsSource> newsSources;
    private ArrayAdapter<NewsSource> adapter;
    private ListView lv;
    private AlertDialog.Builder dialog_builder;
    private AlertDialog.Builder startUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsSources = new ArrayList<>();
        dialog_builder = new AlertDialog.Builder(MainActivity.this);
        startUp = new AlertDialog.Builder(this)
                .setTitle("Disclaimer")
                .setMessage("This is not the official Malaysiakini application. It will only read the news aloud.")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        //Display disclaimer on first run
        checkFirstRun();

        lv = findViewById(R.id.news_list);
        newsSources.add(new NewsSource("Malaysiakini", "https://www.malaysiakini.com/"));
        adapter = new ArrayAdapter<NewsSource>(this, android.R.layout.simple_list_item_1, newsSources){
                @Override
                public View getView(int pos, View convertView, ViewGroup parent){
                    View view = super.getView(pos, convertView, parent);

                    TextView tv = view.findViewById(android.R.id.text1);
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);

                    LayoutParams params = view.getLayoutParams();
                    params.height = 125;
                    view.setLayoutParams(params);

                    return view;
                }
        };

        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0){
                    toSection();
                }
            }
        });
    }

    //Go to login
    public void toLogin(View view){

        new AlertDialog.Builder(this).
                setTitle("Info")
                .setMessage("Please click the Finish button after logging in")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MainActivity.this, LoginViewActivity.class);
                        startActivity(intent);
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                    }
                })
                .show();
    }

    //Go to news section
    public void toSection(){
        Intent toNewsSection = new Intent(MainActivity.this, NewsSectionActivity.class);
        startActivity(toNewsSection);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    public void onBackPressed()
    {
        //Quit app
        if(backButtonCount >= 1)
        {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
        else
        {
            Toast.makeText(this, "Press the back button once again to close the application.", Toast.LENGTH_SHORT).show();
            backButtonCount++;
        }
    }

    private void checkFirstRun(){
        boolean firstRun = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("firstRun", true);
        if(firstRun){
            startUp.show();

            getSharedPreferences("settings", MODE_PRIVATE)
                    .edit()
                    .putBoolean("firstRun", false)
                    .apply();
        }
    }
}
