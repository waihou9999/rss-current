package com.alifabdulrahman.malaysiakinireader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class LoginViewActivity extends AppCompatActivity {

    private WebView webView;
    private String cookies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);


        webView.loadUrl("https://membership.malaysiakini.com/auth/login");


    }

    @Override
    public void onBackPressed() {
        if(webView.canGoBack())
            webView.goBack();
        else
            super.onBackPressed();

        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    public void finish(View view){
        Intent goBack = new Intent(LoginViewActivity.this, MainActivity.class);
        startActivity(goBack);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
