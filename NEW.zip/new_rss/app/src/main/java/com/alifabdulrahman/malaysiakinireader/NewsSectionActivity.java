package com.alifabdulrahman.malaysiakinireader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsSectionActivity extends AppCompatActivity {
    private ArrayList<NewsSectionData> newsSection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_section);
        newsSection = new ArrayList<>();

        newsSection.add(new NewsSectionData("News", "https://www.malaysiakini.com/rss/en/news.rss"));
        newsSection.add(new NewsSectionData("Opinions", "https://www.malaysiakini.com/rss/en/columns.rss"));
//        newsSection.add(new NewsSectionData("Parliament", "https://m.malaysiakini.com/en/tag/parliament"));
//        newsSection.add(new NewsSectionData("Editor's Pick", "https://m.malaysiakini.com/en/tag/editors%20pick"));
//        newsSection.add(new NewsSectionData("Special Report", "https://m.malaysiakini.com/en/tag/special%20report"));
//        newsSection.add(new NewsSectionData("Roundup", "https://m.malaysiakini.com/en/tag/kiniroundup"));
//        newsSection.add(new NewsSectionData("Opinions", "https://m.malaysiakini.com/en/latest/columns"));
        newsSection.add(new NewsSectionData("Letters", "https://www.malaysiakini.com/rss/en/letters.rss"));
//        newsSection.add(new NewsSectionData("Yoursay", "https://m.malaysiakini.com/en/tag/yoursay"));

        final ArrayAdapter<NewsSectionData> adapter = new ArrayAdapter<NewsSectionData>(this, android.R.layout.simple_list_item_1, newsSection){
            @Override
            public View getView(int pos, View convertView, ViewGroup parent){
                View view = super.getView(pos, convertView, parent);

                TextView tv = view.findViewById(android.R.id.text1);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);

                ViewGroup.LayoutParams params = view.getLayoutParams();
                params.height = 100;
                view.setLayoutParams(params);

                return view;
            }
        };
        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String url = adapter.getItem(position).getSectionLink();
                String newsType = adapter.getItem(position).getSectionName();
                Intent toNewsListing = new Intent(NewsSectionActivity.this, ArticleListingActivity.class);
                toNewsListing.putExtra("URL", url);
                toNewsListing.putExtra("NewsType", newsType);
                startActivity(toNewsListing);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

    @Override
    public void onBackPressed(){
        finish();
        super.onBackPressed();
        Intent toMain = new Intent(NewsSectionActivity.this, MainActivity.class);
        startActivity(toMain);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }



}
